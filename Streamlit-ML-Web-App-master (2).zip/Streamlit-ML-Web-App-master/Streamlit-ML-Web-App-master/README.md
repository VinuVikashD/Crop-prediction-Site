# Streamlit-ML-Web-App
 A machine learning model that predicts the possibility of fire taking place , deployed on webpage using streamlit library
